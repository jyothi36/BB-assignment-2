function fun1(n1,n2,n3){
    var a = n1;
    var b = n2;
    var c = n3;
    console.log(a);
    console.log(b);
    console.log(c);
}
fun1(2,"Jyothi",4);