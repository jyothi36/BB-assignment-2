function string_val() {
    return "Hello, World!";
  }
  
  // Call the function and store the result in a variable
  const myString = string_val();
  
  // Display the result
  console.log(myString);